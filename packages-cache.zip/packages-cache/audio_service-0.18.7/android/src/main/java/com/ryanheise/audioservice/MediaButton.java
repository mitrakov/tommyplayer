package com.ryanheise.audioservice;

public enum MediaButton {
    media,
    next,
    previous
}
