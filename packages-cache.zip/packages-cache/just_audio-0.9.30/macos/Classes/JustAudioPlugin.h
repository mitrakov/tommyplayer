#import <FlutterMacOS/FlutterMacOS.h>

@interface JustAudioPlugin : NSObject<FlutterPlugin>
@end
