## 0.0.1-beta.7

* Fix build when targeting Android 13.
* Add MediaItem.artHeaders.

## 0.0.1-beta.6

* Update documentation/example for Android 12.
* Migrate from pedantic to flutter_lints.
* Support content:// art URIs on Android (@nt4f04uNd).

## 0.0.1-beta.5

* Fix bug in stop.

## 0.0.1-beta.4

* Implement disposeAllPlayers.

## 0.0.1-beta.3

* Fix build when targeting Android 12.

## 0.0.1-beta.2

* Remove Android notification on stop.

## 0.0.1-beta.1

* Disable next/prev buttons when boundary reached.

## 0.0.1-beta.0+1

* Fix README typo.

## 0.0.1-beta.0

* Prerelease of initial version.
