## 0.1.0

* Remove unused androidEnableQueue option
* Add setSpeed to MediaActionMessage enum (@nt4f04uNd)

## 0.0.1

* Initial release.
