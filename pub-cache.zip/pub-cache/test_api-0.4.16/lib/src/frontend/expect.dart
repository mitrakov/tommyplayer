// Copyright (c) 2021, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

@Deprecated('Moved to src/expect/expect.dart')
library test_api.src.frontend.expect;

// Temporary re-export to avoid churn in analyzer tests.
export '../expect/expect.dart';
