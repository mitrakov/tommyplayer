## 2.1.0

* Migrate to null-safety.

## 2.0.3

* Fixed some hints.

## 2.0.2

* Updated description.

## 2.0.1

* Added example.
* Added CHANGELOG.md.
* Updated description.
* Formatted lib/xxtea.dart.

## 2.0.0

* Changed the static XXTEA class to a normal class.
* Added const xxtea.
* Added xxteaEncrypt, xxteaDecrypt, xxteaEncryptToString, xxteaDecryptToString.
* Fixed compatibility with Dart 2.

## 1.0.0

* Initial Open Source release.
