Future main() async {
  /// This package is not intended for direct use.
  ///
  /// See [sqflite](https://pub.dev/packages/sqflite)
}
