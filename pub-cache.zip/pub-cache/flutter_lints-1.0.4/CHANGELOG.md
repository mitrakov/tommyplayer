## 1.0.4

* Small update to readme

## 1.0.3

* More small updates to readme

## 1.0.2

* Small updates to readme

## 1.0.1

* Added an example project

## 1.0.0

* Initial release
