#import "IndexedPlayerItem.h"
#import "IndexedAudioSource.h"

@implementation IndexedPlayerItem
@synthesize audioSource;
@end
