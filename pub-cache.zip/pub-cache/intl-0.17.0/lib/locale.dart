/// This library provides access to the [Locale] class.
export 'src/locale.dart';
